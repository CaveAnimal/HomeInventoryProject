"""Home inventory application."""
